from django.shortcuts import render
from index.models import *


# 歌曲排行榜
def rankingView(request):
    # 搜索栏热搜显示
    searchs = Dynamic.objects.select_related('song').order_by('-search').all()[:4]
    # 标签
    labels = Label.objects.all()
    # 参数type
    t = request.GET.get('type', '')
    # 类型排名
    if t:
        dynamics = Dynamic.objects.select_related('song').filter(song__label=t).order_by('-plays').all()[:8]
    # 全站排名
    else:
        dynamics = Dynamic.objects.select_related('song').order_by('-plays').all()[:10]
    return render(request, 'ranking.html', locals())
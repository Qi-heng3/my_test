from django.shortcuts import render, redirect
from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger
from django.shortcuts import reverse
from django.db.models import Q, F
from index.models import *


# 搜索歌曲
def searchView(request, page):
    if request.method == 'GET':
        # 搜索框常搜显示
        searchs = Dynamic.objects.select_related('song').order_by('-search').all()[:6]
        # 搜索内容
        kword = request.session.get('kword', '')
        # 通过歌曲名，作者进行搜索
        if kword:
            songs = Song.objects.filter(Q(name__icontains=kword) | Q(singer=kword)).order_by('-release').all()
        else:
            # 关键词为空，显示100条，按照发行时间排序
            songs = Song.objects.order_by('-release').all()[:100]
        paginator = Paginator(songs, 9)  # 每页最多显示9条
        try:
            pages = paginator.page(page)
        except PageNotAnInteger:
            pages = paginator.page(1)
        except EmptyPage:
            pages = paginator.page(paginator.num_pages)
        # 更新搜索记录
        if kword:
            idList = Song.objects.filter(name__icontains=kword)
            for i in idList:
                dynamics = Dynamic.objects.filter(song_id=i.id)
                # 已存在，直接增加
                if dynamics:
                    dynamics.update(search=F('search') + 1)
                # 不存在就创建
                else:
                    dynamic = Dynamic(plays=0, search=1, download=0, song_id=i.id)
                    dynamic.save()
        return render(request, 'search.html', locals())
    else:
        request.session['kword'] = request.POST.get('kword', '')
        return redirect(reverse('search', kwargs={'page': 1}))

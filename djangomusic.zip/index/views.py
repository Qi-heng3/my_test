from django.shortcuts import render
from .models import *


# 首页
def indexView(request):
    # 关联查询所有歌曲动态信息
    songDynamic = Dynamic.objects.select_related('song')
    # 搜索框下的热搜歌曲
    searchs = songDynamic.order_by('-search').all()[:6]
    # 音乐分类模块
    labels = Label.objects.all()
    # 热门歌曲模块
    popular = songDynamic.order_by('-plays').all()[:10]
    # 新歌推荐数据
    recommend = Song.objects.order_by('-release').all()[:9]
    # 热门搜索
    downloads = songDynamic.order_by('-download').all()[:6]
    # 热门下载
    tabs = [searchs[:6], downloads]
    return render(request, 'index.html', locals())  # locals() 函数会以字典类型返回当前位置的全部局部变量


# 自定义404和500的视图函数
def page_not_found(request, exception):
    return render(request, '404.html', status=404)


def page_error(request):
    return render(request, '404.html', status=500)

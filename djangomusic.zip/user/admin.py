from django.contrib import admin
from .models import MyUser
from django.contrib.auth.admin import UserAdmin


@admin.register(MyUser)
class MyUserAdmin(UserAdmin):
    list_display = ['id', 'username', 'mobile', 'password']
    # 设置可搜索的字段并在Admin后台数据生成搜索框
    search_fields = ['username', 'mobile']
    # 设置排序方式
    ordering = ['id']
